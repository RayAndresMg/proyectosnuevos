﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StudentManagement.Security.CustomTokenProvider
{


    /// <summary>
    /// 自定义的令牌配置类
    /// </summary>
    public class CustomEmailConfirmationTokenProviderOptions:DataProtectionTokenProviderOptions
    {



    }
}
