﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StudentManagement.Security.CustomTokenProvider
{
    public class DataProtectionPurposeStrings
    {

        public readonly string StudentIdRouteValue = "StudentIdRouteValue";

    }
}
